package com.pubgbooster.vpn

import android.app.Application
import android.content.Context
import com.pubgbooster.vpn.manager.PreferenceManager
import com.pubgbooster.vpn.util.LocaleHelper

class PubgBoosterApp : Application() {

    override fun onCreate() {
        super.onCreate()
        PreferenceManager.init(this)
    }

    override fun attachBaseContext(base: Context) {
        val lang = base.getSharedPreferences("pubg_booster_prefs", MODE_PRIVATE)
            .getString("language", "ar") ?: "ar"
        super.attachBaseContext(LocaleHelper.setLocale(base, lang))
    }
}
