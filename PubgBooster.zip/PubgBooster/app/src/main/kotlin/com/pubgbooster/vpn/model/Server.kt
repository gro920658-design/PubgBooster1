package com.pubgbooster.vpn.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Server(
    val id: String,
    val nameKey: String,       // String resource key
    val regionKey: String,     // Region name key
    val flag: String,          // Emoji flag
    val host: String,          // Server host IP/domain
    val port: Int,             // WireGuard port
    val wgPublicKey: String,   // WireGuard public key
    val pubgRegion: PubgRegion,
    var ping: Int = -1,        // -1 = not measured
    var isRecommended: Boolean = false,
    var isOnline: Boolean = true
) : Parcelable

enum class PubgRegion(val regionCode: String) {
    ASIA("AS"),
    SOUTH_ASIA("SAC"),
    SOUTHEAST_ASIA("SEA"),
    MIDDLE_EAST("ME"),
    EUROPE("EU"),
    NORTH_AMERICA("NA"),
    SOUTH_AMERICA("SA"),
    EAST_EUROPE("RU"),
    JAPAN("JP"),
    KOREA("KR")
}

@Parcelize
data class ConnectionStats(
    val ping: Int = 0,
    val downloadSpeed: Double = 0.0,
    val uploadSpeed: Double = 0.0,
    val packetLoss: Float = 0f,
    val jitter: Int = 0,
    val connectedTime: Long = 0L
) : Parcelable

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    ERROR
}
