package com.pubgbooster.vpn

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.pubgbooster.vpn.databinding.ActivitySplashBinding

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Animations
        val logoAnim = AnimationUtils.loadAnimation(this, R.anim.splash_logo)
        val textAnim = AnimationUtils.loadAnimation(this, R.anim.splash_text)

        binding.ivLogo.startAnimation(logoAnim)
        binding.tvAppName.startAnimation(textAnim)
        binding.tvTagline.startAnimation(textAnim)

        // Animate loading bar
        binding.progressBar.animate()
            .scaleX(1f)
            .setDuration(2000)
            .start()

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
            finish()
        }, 2500)
    }
}
