package com.pubgbooster.vpn.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.pubgbooster.vpn.MainActivity
import com.pubgbooster.vpn.R
import com.pubgbooster.vpn.manager.ServerManager
import com.pubgbooster.vpn.model.ConnectionState
import com.pubgbooster.vpn.model.Server
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel

class PubgVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.pubgbooster.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.pubgbooster.vpn.DISCONNECT"
        const val EXTRA_SERVER_ID = "server_id"
        const val CHANNEL_ID = "pubg_vpn_channel"
        const val NOTIFICATION_ID = 1001

        var connectionState = ConnectionState.DISCONNECTED
        var currentPing = 0
        var connectedServer: Server? = null
        var onStateChanged: ((ConnectionState) -> Unit)? = null
        var onStatsUpdated: ((Int, Double, Double) -> Unit)? = null // ping, down, up
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var serviceJob: Job? = null
    private var pingJob: Job? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val serverId = intent.getStringExtra(EXTRA_SERVER_ID) ?: return START_NOT_STICKY
                val server = ServerManager.getServerById(serverId) ?: return START_NOT_STICKY
                startVpn(server)
            }
            ACTION_DISCONNECT -> stopVpn()
        }
        return START_STICKY
    }

    private fun startVpn(server: Server) {
        updateState(ConnectionState.CONNECTING)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification(server))

        serviceJob = serviceScope.launch {
            try {
                // إنشاء VPN interface
                vpnInterface = buildVpnInterface(server)
                connectedServer = server

                // بدء التوصيل
                delay(1500) // Simulated connection time
                updateState(ConnectionState.CONNECTED)
                updateNotification(server)

                // بدء قياس البينج
                startPingMonitor(server)

                // بدء نقل البيانات
                runTunnel(server)

            } catch (e: Exception) {
                e.printStackTrace()
                updateState(ConnectionState.ERROR)
                stopVpn()
            }
        }
    }

    private fun buildVpnInterface(server: Server): ParcelFileDescriptor {
        val builder = Builder()
            .setSession("PUBG Booster - ${server.flag}")
            .addAddress("10.0.0.2", 24)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .setMtu(1420)
            .setBlocking(true)

        // توجيه كل ترافيك ببجي فقط (الطريقة الذكية)
        ServerManager.pubgPackages.forEach { pkg ->
            try {
                builder.addAllowedApplication(pkg)
            } catch (e: Exception) {
                // التطبيق غير مثبت - تجاهل
            }
        }

        // إذا لم يكن هناك تطبيقات ببجي، وجّه كل الترافيك
        builder.addRoute("0.0.0.0", 0)

        // السماح للسيرفر بالمرور بدون VPN
        try {
            protect(
                java.net.Socket().also {
                    it.connect(InetSocketAddress(server.host, server.port), 5000)
                }
            )
        } catch (ignored: Exception) {}

        return builder.establish()
            ?: throw Exception("Failed to establish VPN")
    }

    private suspend fun runTunnel(server: Server) {
        withContext(Dispatchers.IO) {
            val vpnFd = vpnInterface ?: return@withContext
            val inputStream = FileInputStream(vpnFd.fileDescriptor)
            val outputStream = FileOutputStream(vpnFd.fileDescriptor)
            val buffer = ByteBuffer.allocate(65536)
            val packet = ByteArray(65536)

            try {
                // UDP tunnel to server
                val tunnel = DatagramChannel.open()
                tunnel.connect(InetSocketAddress(server.host, server.port))
                protect(tunnel.socket())

                while (isActive && connectionState == ConnectionState.CONNECTED) {
                    // قراءة من VPN interface وإرسال للسرفر
                    val length = inputStream.read(packet)
                    if (length > 0) {
                        buffer.clear()
                        buffer.put(packet, 0, length)
                        buffer.flip()
                        tunnel.write(buffer)
                    }

                    // استقبال من السرفر وإرسال لـ VPN interface
                    buffer.clear()
                    val received = tunnel.read(buffer)
                    if (received > 0) {
                        outputStream.write(buffer.array(), 0, received)
                    }

                    delay(1)
                }
                tunnel.close()
            } catch (e: Exception) {
                if (connectionState == ConnectionState.CONNECTED) {
                    updateState(ConnectionState.ERROR)
                }
            }
        }
    }

    private fun startPingMonitor(server: Server) {
        pingJob = serviceScope.launch {
            while (isActive && connectionState == ConnectionState.CONNECTED) {
                val ping = ServerManager.measurePing(server.host, server.port)
                currentPing = if (ping > 0) ping else currentPing

                // محاكاة إحصائيات الشبكة
                val download = (50 + Math.random() * 100)
                val upload = (10 + Math.random() * 30)

                withContext(Dispatchers.Main) {
                    onStatsUpdated?.invoke(currentPing, download, upload)
                }

                delay(3000) // قياس كل 3 ثواني
            }
        }
    }

    private fun stopVpn() {
        updateState(ConnectionState.DISCONNECTING)
        pingJob?.cancel()
        serviceJob?.cancel()

        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        vpnInterface = null
        connectedServer = null
        currentPing = 0

        updateState(ConnectionState.DISCONNECTED)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun updateState(state: ConnectionState) {
        connectionState = state
        CoroutineScope(Dispatchers.Main).launch {
            onStateChanged?.invoke(state)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "PUBG Booster VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "PUBG VPN Service"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(server: Server): Notification {
        val disconnectIntent = Intent(this, PubgVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPendingIntent = PendingIntent.getService(
            this, 0, disconnectIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val mainIntent = Intent(this, MainActivity::class.java)
        val mainPendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_vpn_key)
            .setContentTitle("🎮 PUBG Booster")
            .setContentText("${server.flag} متصل بـ ${server.regionKey}")
            .setContentIntent(mainPendingIntent)
            .addAction(R.drawable.ic_stop, "قطع الاتصال", disconnectPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(server: Server) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(server))
    }

    override fun onDestroy() {
        stopVpn()
        serviceScope.cancel()
        super.onDestroy()
    }
}
