package com.pubgbooster.vpn

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.pubgbooster.vpn.adapter.ServerAdapter
import com.pubgbooster.vpn.databinding.ActivityServerSelectBinding
import com.pubgbooster.vpn.manager.PreferenceManager
import com.pubgbooster.vpn.manager.ServerManager
import com.pubgbooster.vpn.model.Server
import kotlinx.coroutines.*

class ServerSelectActivity : AppCompatActivity() {

    private lateinit var binding: ActivityServerSelectBinding
    private lateinit var adapter: ServerAdapter
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityServerSelectBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        loadServers()
        pingServers()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.select_server)
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
    }

    private fun setupRecyclerView() {
        val selectedId = PreferenceManager.selectedServerId
        adapter = ServerAdapter(
            servers = ServerManager.allServers.toMutableList(),
            selectedServerId = selectedId,
            onServerSelected = { server -> onServerSelected(server) }
        )

        binding.rvServers.layoutManager = LinearLayoutManager(this)
        binding.rvServers.adapter = adapter
    }

    private fun loadServers() {
        // Group by region
        val grouped = ServerManager.getServersByRegion()
        // Show servers grouped
        adapter.updateData(ServerManager.allServers)
    }

    private fun pingServers() {
        binding.progressPinging.visibility = View.VISIBLE
        binding.tvPingingStatus.visibility = View.VISIBLE

        scope.launch {
            ServerManager.pingAllServers { server ->
                runOnUiThread {
                    adapter.updateServerPing(server)
                    binding.tvPingingStatus.text = getString(R.string.pinging_servers)
                }
            }
            binding.progressPinging.visibility = View.GONE
            binding.tvPingingStatus.visibility = View.GONE
        }
    }

    private fun onServerSelected(server: Server) {
        PreferenceManager.selectedServerId = server.id
        setResult(RESULT_OK, Intent().apply {
            putExtra("server_id", server.id)
        })
        finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
